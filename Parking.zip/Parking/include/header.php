<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Parking</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<link rel="stylesheet" href="estilos.css">

	<script src="https://kit.fontawesome.com/234c17fedc.js" crossorigin="anonymous"></script
</head>
<body>

	<nav class="navbar navbar-dark bg-dark">
		<div class="container">
			<a href="index.php" class="navbar-brand"> PARKING - REGISTRO </a>
		</div>
		
	</nav>